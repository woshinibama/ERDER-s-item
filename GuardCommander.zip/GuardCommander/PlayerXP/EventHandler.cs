﻿using Smod2;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.EventSystem.Events;
using System.Collections.Generic;
using System;


namespace level
{
    class EventHandler : IEventHandlerRoundStart, IEventHandler, IEventHandlerPlayerPickupItem, IEventHandlerRoundEnd, IEventHandlerPlayerHurt, IEventHandlerPlayerDie
    {

        public int geid = 1;
        private Plugin plugin;
        private Server server;
        private Player guard;
        private bool g = true;

        public EventHandler(Plugin plugin)
        {
            this.plugin = plugin;
            this.server = plugin.Server;
        }
        public void OnRoundStart(RoundStartEvent ev)
        {
            List<Player> er = new List<Player>();
            if (g == true)
            foreach (Player gu in ev.Server.GetPlayers(""))
            {
                if (gu.TeamRole.Role == Role.FACILITY_GUARD) er.Add(gu);
                {
                    er.Add(gu);
                }
            }
            for (int i = 0; i < er.Count; i++)
            {
                if (i == 0)
                {
                    guard = er[i];
                    this.geid = guard.PlayerId;
                    guard.GiveItem(ItemType.LOGICER);

                    guard.SetRank("cyan", "Guard-Commander", null);
                    guard.PersonalBroadcast(10, "你是[<color=grey>保安指挥官</color>]\n你比别的保安...嗯...也就那样吧", false);
                }
            }
        }

        public void OnRoundEnd(RoundEndEvent ev)
        {
            geid = 0;
        }

        public void OnPlayerPickupItem(PlayerPickupItemEvent ev)
        {
            if (ev.Player.PlayerId == this.geid)
            {
                if (ev.Item.ItemType == ItemType.JANITOR_KEYCARD)
                {
                    ev.ChangeTo = ItemType.GUARD_KEYCARD;
                }
                if (ev.Item.ItemType == ItemType.SCIENTIST_KEYCARD)
                {
                    ev.ChangeTo = ItemType.SENIOR_GUARD_KEYCARD;
                }
                if (ev.Item.ItemType == ItemType.MAJOR_SCIENTIST_KEYCARD)
                {
                    ev.ChangeTo = ItemType.MTF_LIEUTENANT_KEYCARD;
                }
                if (ev.Item.ItemType == ItemType.ZONE_MANAGER_KEYCARD)
                {
                    ev.ChangeTo = ItemType.MTF_COMMANDER_KEYCARD;
                }
            }
        }

        public void OnPlayerDie(PlayerDeathEvent ev)
        {
            if (ev.Player.PlayerId == this.geid)
            {
                geid = 0;
                PluginManager.Manager.Server.Map.AnnounceCustomMessage("GUARD COMMAND CONTAINEDSUCCESSFULLY");
            }
        }

        public void OnPlayerHurt(PlayerHurtEvent ev)
        {
            if (ev.Player.PlayerId == this.geid)
            {
                if (ev.DamageType == DamageType.COM15 || ev.DamageType == DamageType.E11_STANDARD_RIFLE || ev.DamageType == DamageType.LOGICER || ev.DamageType == DamageType.MP7 || ev.DamageType == DamageType.P90 || ev.DamageType == DamageType.USP)
                {
                    ev.Damage = (ev.Damage * 75) / 100;
                }
            }
        }
    }
}

            