﻿using System;
using System.IO;
using Smod2;
using Smod2.Attributes;
using Smod2.API;
using System.Collections.Generic;

namespace level
{
	[PluginDetails(
	author = "erder",
	name = "Guard Commander",
	description = "lazy",
	id = "erder.Guard Commander",
	version = "1.0",
	SmodMajor = 3,
	SmodMinor = 4,
	SmodRevision = 1
	)]
	public class PlayerXP : Plugin
	{
		public static Plugin plugin;

        public override void OnDisable()
        {
            this.Info("Guard Commander loading success");
        }
		public override void OnEnable()
		{
			plugin = this;
            this.Info("Guard Commander loading failed");
        }

		public override void Register()
		{
			AddEventHandlers(new EventHandler(this));
        }
	}
}
